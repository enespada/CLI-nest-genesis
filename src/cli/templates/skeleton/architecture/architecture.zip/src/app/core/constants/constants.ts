export const enum ENV {
  DEV = 'DEV',
  PRE = 'PRE',
  PROD = 'PROD',
}

export enum Order {
  ASC = "ASC",
  DESC = "DESC",
}