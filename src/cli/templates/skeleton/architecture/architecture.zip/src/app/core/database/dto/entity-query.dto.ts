import { FindOptionsWhere } from "typeorm";

export interface EntityQuery<T> {
  where?: FindOptionsWhere<T> | FindOptionsWhere<T>[];
  limit?: number;
  orFail?: boolean;
}
